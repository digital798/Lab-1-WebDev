﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AverageUnitsShipped
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Units = New System.Windows.Forms.Label()
        Me.UnitsInput = New System.Windows.Forms.TextBox()
        Me.Days = New System.Windows.Forms.Label()
        Me.AverageBox = New System.Windows.Forms.Label()
        Me.EnterButton = New System.Windows.Forms.Button()
        Me.ResetButton = New System.Windows.Forms.Button()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.OutputBox = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Units
        '
        Me.Units.Location = New System.Drawing.Point(47, 9)
        Me.Units.Name = "Units"
        Me.Units.Size = New System.Drawing.Size(55, 25)
        Me.Units.TabIndex = 0
        Me.Units.Text = "&Units:"
        Me.Units.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'UnitsInput
        '
        Me.UnitsInput.Location = New System.Drawing.Point(108, 12)
        Me.UnitsInput.Name = "UnitsInput"
        Me.UnitsInput.Size = New System.Drawing.Size(66, 22)
        Me.UnitsInput.TabIndex = 1
        '
        'Days
        '
        Me.Days.Location = New System.Drawing.Point(180, 12)
        Me.Days.Name = "Days"
        Me.Days.Size = New System.Drawing.Size(65, 25)
        Me.Days.TabIndex = 2
        Me.Days.Text = "&Day: 1"
        Me.Days.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'AverageBox
        '
        Me.AverageBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.AverageBox.Location = New System.Drawing.Point(50, 189)
        Me.AverageBox.Name = "AverageBox"
        Me.AverageBox.Size = New System.Drawing.Size(185, 23)
        Me.AverageBox.TabIndex = 4
        Me.AverageBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'EnterButton
        '
        Me.EnterButton.Location = New System.Drawing.Point(12, 215)
        Me.EnterButton.Name = "EnterButton"
        Me.EnterButton.Size = New System.Drawing.Size(86, 26)
        Me.EnterButton.TabIndex = 5
        Me.EnterButton.Text = "&Enter"
        Me.EnterButton.UseVisualStyleBackColor = True
        '
        'ResetButton
        '
        Me.ResetButton.Location = New System.Drawing.Point(104, 215)
        Me.ResetButton.Name = "ResetButton"
        Me.ResetButton.Size = New System.Drawing.Size(78, 26)
        Me.ResetButton.TabIndex = 6
        Me.ResetButton.Text = "&Reset"
        Me.ResetButton.UseVisualStyleBackColor = True
        '
        'ExitButton
        '
        Me.ExitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.ExitButton.Location = New System.Drawing.Point(188, 215)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(82, 26)
        Me.ExitButton.TabIndex = 7
        Me.ExitButton.Text = "E&xit"
        Me.ExitButton.UseVisualStyleBackColor = True
        '
        'OutputBox
        '
        Me.OutputBox.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.OutputBox.Location = New System.Drawing.Point(51, 40)
        Me.OutputBox.Multiline = True
        Me.OutputBox.Name = "OutputBox"
        Me.OutputBox.ReadOnly = True
        Me.OutputBox.Size = New System.Drawing.Size(183, 139)
        Me.OutputBox.TabIndex = 8
        '
        'AverageUnitsShipped
        '
        Me.AcceptButton = Me.EnterButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.ExitButton
        Me.ClientSize = New System.Drawing.Size(282, 253)
        Me.Controls.Add(Me.OutputBox)
        Me.Controls.Add(Me.ExitButton)
        Me.Controls.Add(Me.ResetButton)
        Me.Controls.Add(Me.EnterButton)
        Me.Controls.Add(Me.AverageBox)
        Me.Controls.Add(Me.Days)
        Me.Controls.Add(Me.UnitsInput)
        Me.Controls.Add(Me.Units)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "AverageUnitsShipped"
        Me.Text = "Average Units Shipped"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Units As Label
    Friend WithEvents UnitsInput As TextBox
    Friend WithEvents Days As Label
    Friend WithEvents AverageBox As Label
    Friend WithEvents EnterButton As Button
    Friend WithEvents ResetButton As Button
    Friend WithEvents ExitButton As Button
    Friend WithEvents OutputBox As TextBox
End Class

﻿Public Class AverageUnitsShipped
    Dim length As Integer = 1
    Dim array(6) As Integer
    Dim sum As Integer
    Dim userInput As Integer
    Private Sub EnterButton_Click(sender As Object, e As EventArgs) Handles EnterButton.Click
        If Integer.TryParse(UnitsInput.Text, userInput) And (userInput > 0) And (userInput < 1000) Then
            array(length - 1) = userInput
            length += 1
            OutputBox.AppendText(UnitsInput.Text & vbCrLf)
            Days.Text = "Day: " & length
            UnitsInput.Clear()
        Else MessageBox.Show("Please input a whole number between 0 and 1000", "Error")
            UnitsInput.Clear()
        End If
        If length = 8 Then
            Days.Text = "Day: " & 7
            UnitsInput.ReadOnly = True
            EnterButton.Enabled = False
            For i = 0 To 6
                sum += array(i)
            Next
            AverageBox.Text = sum
        End If
    End Sub

    Private Sub Days_Click(sender As Object, e As EventArgs) Handles Days.Click
    End Sub

    Private Sub ResetButton_Click(sender As Object, e As EventArgs) Handles ResetButton.Click
        OutputBox.Text = ""
        UnitsInput.Text = ""
        AverageBox.Text = ""
        Days.Text = "Day: 1"
        UnitsInput.Focus()
        length = 1
        EnterButton.Enabled = True
        UnitsInput.ReadOnly = False
    End Sub

    Private Sub ExitButton_Click(sender As Object, e As EventArgs) Handles ExitButton.Click
        Application.Exit()
    End Sub
End Class
